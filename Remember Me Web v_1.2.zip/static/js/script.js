document.addEventListener('DOMContentLoaded', function() {
    // Анимация кнопок
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
        });
        btn.addEventListener('mouseleave', function() {
            this.style.transform = '';
            this.style.boxShadow = '';
        });
    });

    // Автоотправка формы при очистке поиска
    const searchInput = document.querySelector('.search-form input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            if (this.value.trim() === '' && this.value.length === 0) {
                this.form.submit();
            }
        });
    }
});

// Анимация для карточек папок
const folderCards = document.querySelectorAll('.folder-card');
folderCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
        this.style.boxShadow = '0 6px 12px rgba(0,0,0,0.1)';
    });
    card.addEventListener('mouseleave', function() {
        this.style.transform = '';
        this.style.boxShadow = '0 4px 15px rgba(0,0,0,0.05)';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Подтверждение удаления
    const deleteForms = document.querySelectorAll('.delete-form');
    deleteForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('Вы уверены, что хотите удалить этот элемент?')) {
                e.preventDefault();
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const deleteAccountForm = document.querySelector('form[action*="delete_account"]');
    if (deleteAccountForm) {
        deleteAccountForm.addEventListener('submit', function(e) {
            if (!confirm('Вы уверены, что хотите полностью удалить свой аккаунт и все данные? Это действие невозможно отменить.')) {
                e.preventDefault();
            }
        });
    }
});