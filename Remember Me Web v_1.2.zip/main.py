from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import json
from flask import jsonify
from time_service import TimeService

app = Flask(__name__)
app.secret_key = 'dev-secret-key-123'

# Настройка базы данных
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'user_data.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# Модели базы данных
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    entries = db.Column(db.Text, default='[]')
    folders = db.Column(db.Text, default='{}')


# Создаем таблицы
with app.app_context():
    db.create_all()


# Вспомогательные функции
def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Пожалуйста, войдите в систему', 'error')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)

    decorated_function.__name__ = f.__name__
    return decorated_function


def get_current_user_data():
    if 'user_id' not in session:
        return None
    user = User.query.get(session['user_id'])
    if not user:
        return None

    entries = json.loads(user.entries)
    folders = json.loads(user.folders)

    # Сортируем записи по имени + фамилии
    entries.sort(key=lambda x: (x['first_name'].lower(), x['last_name'].lower()))

    # Сортируем папки по имени
    sorted_folders = {k: folders[k] for k in sorted(folders.keys(), key=str.lower)}

    # Сортируем записи внутри каждой папки
    for folder_name in sorted_folders:
        sorted_folders[folder_name].sort(key=lambda eid: (
            entries[eid]['first_name'].lower(),
            entries[eid]['last_name'].lower()
        ))

    return {
        'entries': entries,
        'folders': sorted_folders
    }


def save_user_data(entries, folders):
    if 'user_id' not in session:
        return False

    # Сортируем перед сохранением
    entries.sort(key=lambda x: (x['first_name'].lower(), x['last_name'].lower()))
    sorted_folders = {k: folders[k] for k in sorted(folders.keys(), key=str.lower)}

    user = User.query.get(session['user_id'])
    user.entries = json.dumps(entries)
    user.folders = json.dumps(sorted_folders)
    db.session.commit()
    return True


# Маршруты аутентификации
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Вы успешно вошли в систему', 'success')
            return redirect(url_for('show_entries'))

        flash('Неверное имя пользователя или пароль', 'error')
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if User.query.filter_by(username=username).first():
            flash('Это имя пользователя уже занято', 'error')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_user = User(username=username, password_hash=hashed_password)

        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Регистрация прошла успешно! Теперь вы можете войти.', 'success')
            return redirect(url_for('login'))
        except:
            db.session.rollback()
            flash('Ошибка при регистрации', 'error')
    return render_template('register.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('home'))


# Основные маршруты приложения
@app.route('/')
def home():
    features = [
        {"img": "feature1.png", "text": "Храните информацию о важных людях"},
        {"img": "feature2.png", "text": "Легко находите нужные контакты"},
        {"img": "feature3.png", "text": "Персонализируйте записи с помощью цветов"},
        {"img": "feature4.png", "text": "Добавляйте прозвища для быстрого поиска"},
        {"img": "feature5.png", "text": "Простота и удобство использования"}
    ]
    return render_template('index.html', features=features)


@app.route('/entries')
@login_required
def show_entries():
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    search_query = request.args.get('search', '').lower()
    entries = user_data['entries']

    if search_query:
        filtered_entries = []
        for idx, entry in enumerate(entries):
            if (search_query in entry['first_name'].lower() or
                    search_query in entry['last_name'].lower() or
                    search_query in entry['nickname'].lower()):
                filtered_entries.append((idx, entry))
        entries = filtered_entries
    else:
        entries = list(enumerate(entries))

    return render_template('entries.html', entries=entries, search_query=search_query)


@app.route('/entry/<int:entry_id>')
@login_required
def show_entry(entry_id):  # Оставил оригинальное имя для совместимости с шаблонами
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    entries = user_data['entries']
    if 0 <= entry_id < len(entries):
        return render_template('entry_detail.html', entry=entries[entry_id], entry_id=entry_id)
    return redirect(url_for('show_entries'))


@app.route('/create', methods=['GET', 'POST'])
@login_required
def create_entry():
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    if request.method == 'POST':
        new_entry = {
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'info': request.form['info'],
            'contacts': request.form['contacts'],
            'nickname': request.form['nickname'],
            'color': request.form['color']
        }
        user_data['entries'].append(new_entry)
        save_user_data(user_data['entries'], user_data['folders'])
        return redirect(url_for('show_entries'))

    return render_template('create.html')


@app.route('/edit/<int:entry_id>', methods=['GET', 'POST'])
@login_required
def edit_entry(entry_id):
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    entries = user_data['entries']
    if 0 <= entry_id < len(entries):
        if request.method == 'POST':
            entries[entry_id] = {
                'first_name': request.form['first_name'],
                'last_name': request.form['last_name'],
                'info': request.form['info'],
                'contacts': request.form['contacts'],
                'nickname': request.form['nickname'],
                'color': request.form['color']
            }
            save_user_data(entries, user_data['folders'])
            return redirect(url_for('show_entries'))

        entry = entries[entry_id]
        return render_template('edit.html', entry=entry, entry_id=entry_id)

    return redirect(url_for('show_entries'))


@app.route('/folders')
@login_required
def show_folders():
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    search_query = request.args.get('search', '').lower()
    folders = user_data['folders']

    # Фильтрация папок по поисковому запросу
    if search_query:
        filtered_folders = {
            name: entries for name, entries in folders.items()
            if search_query in name.lower()
        }
    else:
        filtered_folders = folders

    return render_template('folders.html',
                           folders=filtered_folders,
                           all_entries=enumerate(user_data['entries']),
                           search_query=search_query)


@app.route('/folder/<folder_name>')
@login_required
def show_folder(folder_name):
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    search_query = request.args.get('search', '').lower()
    folders = user_data['folders']

    if folder_name in folders:
        entries = []
        for entry_id in folders[folder_name]:
            if 0 <= entry_id < len(user_data['entries']):
                entry = user_data['entries'][entry_id]
                # Фильтрация записей по поисковому запросу
                if not search_query or (
                        search_query in entry['first_name'].lower() or
                        search_query in entry['last_name'].lower() or
                        search_query in entry['nickname'].lower()
                ):
                    entries.append((entry_id, entry))

        return render_template('folder_view.html',
                               folder_name=folder_name,
                               entries=entries,
                               all_entries=user_data['entries'],
                               search_query=search_query)

    return redirect(url_for('show_folders'))


@app.route('/create_folder', methods=['GET', 'POST'])
@login_required
def create_folder():
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    if request.method == 'POST':
        folder_name = request.form['folder_name']
        selected_entries = [int(entry_id) for entry_id in request.form.getlist('entries')]

        user_data['folders'][folder_name] = selected_entries
        save_user_data(user_data['entries'], user_data['folders'])
        return redirect(url_for('show_folders'))

    return render_template('create_folder.html', entries=enumerate(user_data['entries']))


@app.route('/edit_folder/<folder_name>', methods=['GET', 'POST'])
@login_required
def edit_folder(folder_name):
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    folders = user_data['folders']
    if folder_name not in folders:
        return redirect(url_for('show_folders'))

    if request.method == 'POST':
        new_name = request.form['folder_name']
        selected_entries = [int(entry_id) for entry_id in request.form.getlist('entries')]

        if new_name != folder_name:
            del folders[folder_name]

        folders[new_name] = selected_entries
        save_user_data(user_data['entries'], folders)
        return redirect(url_for('show_folders'))

    return render_template('edit_folder.html',
                           folder_name=folder_name,
                           all_entries=enumerate(user_data['entries']),
                           folder_entries=folders.get(folder_name, []))


@app.route('/delete_entry/<int:entry_id>', methods=['POST'])
@login_required
def delete_entry(entry_id):
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    entries = user_data['entries']
    folders = user_data['folders']

    # Удаляем запись из основного списка
    if 0 <= entry_id < len(entries):
        entries.pop(entry_id)

        # Удаляем ссылки на эту запись из всех папок
        for folder_name in list(folders.keys()):
            folders[folder_name] = [eid for eid in folders[folder_name] if eid != entry_id]
            # Обновляем индексы (> entry_id)
            folders[folder_name] = [eid if eid < entry_id else eid - 1 for eid in folders[folder_name]]

        save_user_data(entries, folders)
        flash('Запись успешно удалена', 'success')

    return redirect(url_for('show_entries'))


@app.route('/delete_folder/<folder_name>', methods=['POST'])
@login_required
def delete_folder(folder_name):
    user_data = get_current_user_data()
    if not user_data:
        return redirect(url_for('login'))

    if folder_name in user_data['folders']:
        del user_data['folders'][folder_name]
        save_user_data(user_data['entries'], user_data['folders'])
        flash('Папка успешно удалена', 'success')

    return redirect(url_for('show_folders'))


@app.route('/delete_account', methods=['GET', 'POST'])
@login_required
def delete_account():
    if request.method == 'POST':
        # Подтверждение через ввод пароля
        password = request.form.get('password')
        user = User.query.get(session['user_id'])

        if user and check_password_hash(user.password_hash, password):
            try:
                # Удаляем все данные пользователя
                db.session.delete(user)
                db.session.commit()
                session.clear()
                flash('Ваш аккаунт и все данные успешно удалены', 'success')
                return redirect(url_for('home'))
            except Exception as e:
                db.session.rollback()
                flash('Ошибка при удалении аккаунта', 'error')
        else:
            flash('Неверный пароль', 'error')

    return render_template('delete_account.html')


@app.route('/get_time')
def get_time():
    return jsonify(TimeService.get_world_time())


@app.context_processor
def inject_current_time():
    return {'world_time': TimeService.get_world_time()}


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
