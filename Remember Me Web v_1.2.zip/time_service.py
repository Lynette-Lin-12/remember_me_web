import requests
from datetime import datetime
import pytz
import socket
import time


class TimeService:
    TIMEZONES = {
        'Москва': 'Europe/Moscow',
        'Лондон': 'Europe/London',
        'Нью-Йорк': 'America/New_York',
        'Токио': 'Asia/Tokyo',
        'Сидней': 'Australia/Sydney'
    }

    @staticmethod
    def check_internet():
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False

    @staticmethod
    def get_world_time():
        if not TimeService.check_internet():
            return TimeService.get_fallback_time()

        world_time = {}
        for city, tz in TimeService.TIMEZONES.items():
            try:
                response = requests.get(f"http://worldtimeapi.org/api/timezone/{tz}", timeout=2)
                if response.status_code == 200:
                    data = response.json()
                    dt = datetime.fromisoformat(data['datetime'])
                    world_time[city] = dt.strftime('%H:%M')
                else:
                    world_time[city] = datetime.now(pytz.timezone(tz)).strftime('%H:%M')
            except:
                world_time[city] = datetime.now(pytz.timezone(tz)).strftime('%H:%M')

        return world_time

    @staticmethod
    def get_fallback_time():
        return {city: '--:--' for city in TimeService.TIMEZONES.keys()}